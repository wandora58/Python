def say_hello():
    print('hello')

def say_good():
    print('good')